<?php get_header(); ?>

<?php
// Resolve title, description, pill color based on current term
$arc_title = '';
$arc_desc  = '';
$arc_pill_class = '';
$arc_term  = null;
$arc_parent_term = null;

$category_colors = [
    'selling-a-home'   => 'bc-pill--selling',
    'buying-a-home'    => 'bc-pill--buying',
    'homeowner-guides' => 'bc-pill--homeowner',
    'local-insights'   => 'bc-pill--local',
];

if (is_category()) {
    $arc_term  = get_queried_object();
    $arc_title = $arc_term->name;
    $raw = strip_tags(category_description());
    if (!$raw && $arc_term->parent) {
        $raw = strip_tags(category_description($arc_term->parent));
    }
    if ($raw) $arc_desc = $raw;

    // Determine pill color from this term or its parent
    $root_slug = $arc_term->slug;
    if ($arc_term->parent) {
        $arc_parent_term = get_term($arc_term->parent, 'category');
        $root_slug = $arc_parent_term ? $arc_parent_term->slug : $root_slug;
    }
    $arc_pill_class = $category_colors[$root_slug] ?? 'bc-pill--buying';

} elseif (is_tag()) {
    $arc_term  = get_queried_object();
    $arc_title = $arc_term->name;
    $raw = strip_tags(tag_description());
    if ($raw) $arc_desc = $raw;
    $arc_pill_class = 'bc-pill--buying';
} else {
    $arc_title = 'All Articles';
}

global $wp_query;
$arc_count = (int) $wp_query->found_posts;
?>

<!-- Breadcrumb bar -->
<div class="bc-breadcrumb-bar">
    <div class="bc-container">
        <nav class="bc-breadcrumb" aria-label="Breadcrumb">
            <a href="<?php echo esc_url(home_url('/')); ?>">Blog</a>
            <span aria-hidden="true">&rsaquo;</span>
            <?php if ($arc_parent_term) : ?>
            <a href="<?php echo esc_url(get_category_link($arc_parent_term->term_id)); ?>"><?php echo esc_html($arc_parent_term->name); ?></a>
            <span aria-hidden="true">&rsaquo;</span>
            <?php endif; ?>
            <span class="bc-breadcrumb-current"><?php echo esc_html($arc_title); ?></span>
        </nav>
    </div>
</div>

<!-- Archive hero -->
<section class="bc-blog-archive-hero">
    <div class="bc-container">
        <div class="bc-blog-archive-hero-inner">
            <?php if ($arc_term && (is_category() || is_tag())) : ?>
            <span class="bc-category-pill <?php echo esc_attr($arc_pill_class); ?>"><?php echo esc_html($arc_title); ?></span>
            <?php endif; ?>
            <h1><?php echo esc_html($arc_title); ?></h1>
            <?php if ($arc_desc) : ?>
            <p class="bc-blog-archive-desc"><?php echo esc_html($arc_desc); ?></p>
            <?php endif; ?>
            <div class="bc-blog-archive-count">
                <span>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15" aria-hidden="true"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>
                    <?php echo $arc_count; ?> article<?php echo $arc_count !== 1 ? 's' : ''; ?>
                </span>
            </div>
        </div>
    </div>
</section>

<!-- Card grid -->
<section class="bc-blog-archive-section">
    <div class="bc-container">
        <?php if (have_posts()) : ?>
        <div class="bc-blog-card-grid">
            <?php while (have_posts()) : the_post(); ?>
            <?php echo beycome_blog_card(get_the_ID(), 'beycome-blog-card', true); ?>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <?php
        $total = $GLOBALS['wp_query']->max_num_pages;
        if ($total > 1) :
            $paged = max(1, get_query_var('paged'));
        ?>
        <nav class="bc-pagination" aria-label="Archive pagination">
            <?php if ($paged > 1) : ?>
            <a href="<?php echo esc_url(get_pagenum_link($paged - 1)); ?>" class="bc-page-btn">&larr; Previous</a>
            <?php endif; ?>
            <div class="bc-page-numbers">
                <?php
                $start = max(1, $paged - 2);
                $end = min($total, $paged + 2);
                if ($start > 1) echo '<a href="' . esc_url(get_pagenum_link(1)) . '" class="bc-page-num">1</a>';
                if ($start > 2) echo '<span class="bc-page-ellipsis">&hellip;</span>';
                for ($i = $start; $i <= $end; $i++) :
                ?>
                <a href="<?php echo esc_url(get_pagenum_link($i)); ?>" class="bc-page-num<?php echo ($i === $paged) ? ' active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
                <?php if ($end < $total - 1) echo '<span class="bc-page-ellipsis">&hellip;</span>'; ?>
                <?php if ($end < $total) echo '<a href="' . esc_url(get_pagenum_link($total)) . '" class="bc-page-num">' . $total . '</a>'; ?>
            </div>
            <?php if ($paged < $total) : ?>
            <a href="<?php echo esc_url(get_pagenum_link($paged + 1)); ?>" class="bc-page-btn">Next &rarr;</a>
            <?php endif; ?>
        </nav>
        <?php endif; ?>

        <?php else : ?>
        <div class="bc-blog-no-posts">
            <p>No articles found. <a href="<?php echo esc_url(home_url('/')); ?>">Return to blog home &rarr;</a></p>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>
