<?php get_header(); ?>

<?php
// Helper: resolve a category by slug
function bc_cat($slug) {
    $t = get_term_by('slug', $slug, 'category');
    if (!$t) return ['url' => '#', 'count' => 0, 'id' => 0];
    return ['url' => get_category_link($t->term_id), 'count' => (int)$t->count, 'id' => $t->term_id];
}

// Helper: resolve a tag by slug
function bc_tag($slug) {
    $t = get_term_by('slug', $slug, 'post_tag');
    if (!$t) return ['url' => '#', 'count' => 0, 'id' => 0];
    return ['url' => get_tag_link($t->term_id), 'count' => (int)$t->count, 'id' => $t->term_id];
}

// Subnav: label → category slug
$bc_subnav = [
    'Selling'   => 'selling-a-home',
    'Buying'    => 'buying-a-home',
    'Homeowner' => 'homeowner-guides',
    'Local'     => 'local-insights',
];
?>

<!-- Blog secondary subnav (hidden on homepage via CSS) -->
<nav class="bc-blog-subnav" style="display:none">
    <div class="bc-container">
        <div class="bc-blog-subnav-inner">
            <div class="bc-blog-subnav-links">
                <?php foreach ($bc_subnav as $label => $slug) :
                    $t = get_term_by('slug', $slug, 'category');
                    $url = $t ? get_category_link($t->term_id) : '#';
                    $active = ($t && is_category($t->term_id)) ? ' class="active"' : '';
                ?>
                <a href="<?php echo esc_url($url); ?>"<?php echo $active; ?>><?php echo esc_html($label); ?></a>
                <?php endforeach; ?>
                <a href="https://www.beycome.com/faq">FAQ</a>
            </div>
        </div>
    </div>
</nav>

<!-- Blog hero tagline -->
<section class="bc-blog-hero">
    <div class="bc-container">
        <h1>Real estate,<br>decoded.</h1>
        <p>Guides, market insights, and how-tos, from buying to renting,<br>plus tips on saving equity, pricing smart, and navigating every step.</p>
    </div>
</section>

<?php
// Fetch latest posts — exclude programmatic SEO and reviews categories
$_local_guides   = get_term_by('slug', 'local-guides', 'category');
$_reviews_term   = get_term_by('slug', 'beycome-reviews', 'category');
$_featured_args = [
    'posts_per_page'      => 5,
    'post_status'         => 'publish',
    'ignore_sticky_posts' => true,
];
$_exclude_ids = array_filter([
    $_local_guides ? $_local_guides->term_id : 0,
    $_reviews_term ? $_reviews_term->term_id : 0,
]);
if (!empty($_exclude_ids)) {
    $_featured_args['tax_query'] = [[
        'taxonomy' => 'category',
        'field'    => 'term_id',
        'terms'    => $_exclude_ids,
        'operator' => 'NOT IN',
    ]];
}
$featured_query = new WP_Query($_featured_args);
$featured_posts = $featured_query->posts;
$featured    = !empty($featured_posts) ? $featured_posts[0] : null;
$aside_posts = array_slice($featured_posts, 1, 4);
wp_reset_postdata();
?>

<?php if ($featured) : ?>
<section class="bc-blog-featured-section">
    <div class="bc-container">
        <div class="bc-blog-featured-grid">

            <!-- Big featured card -->
            <?php
            $feat_cats    = get_the_category($featured->ID);
            $feat_cat     = $feat_cats ? $feat_cats[0] : null;
            $feat_time    = beycome_blog_reading_time($featured->ID);
            $feat_has_thumb = has_post_thumbnail($featured->ID);
            ?>
            <a href="<?php echo esc_url(get_permalink($featured->ID)); ?>" class="bc-featured-card">
                <div class="bc-featured-card-img">
                    <?php if ($feat_has_thumb) : echo get_the_post_thumbnail($featured->ID, 'beycome-blog-hero', ['alt' => esc_attr(get_the_title($featured->ID)), 'loading' => 'eager']); else : ?>
                    <div class="bc-featured-card-img-placeholder"></div>
                    <?php endif; ?>
                    <span class="bc-featured-badge">Featured</span>
                </div>
                <div class="bc-featured-card-body">
                    <div class="bc-featured-card-meta">
                        <?php if ($feat_cat) : ?><span class="bc-featured-card-cat"><?php echo esc_html(strtoupper($feat_cat->name)); ?></span> &middot; <?php endif; ?>
                        <?php echo (int)$feat_time; ?> MIN READ
                    </div>
                    <h2 class="bc-featured-card-title"><?php echo esc_html(get_the_title($featured->ID)); ?></h2>
                    <p class="bc-featured-card-excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt($featured->ID) ?: strip_tags(get_post_field('post_content', $featured->ID)), 20, '…')); ?></p>
                </div>
            </a>

            <!-- Aside cards column -->
            <div class="bc-blog-aside-list">
                <?php foreach ($aside_posts as $aside_post) : ?>
                <?php echo beycome_blog_aside_card($aside_post->ID); ?>
                <?php endforeach; ?>
            </div>

        </div>
    </div>
</section>
<?php endif; ?>


<!-- Category strips -->
<?php
$strip_categories = [
    'Selling a Home'   => 'selling-a-home',
    'Buying a Home'    => 'buying-a-home',
    'Homeowner Guides' => 'homeowner-guides',
    'Local Insights'   => 'local-insights',
];
$strip_modifiers = [
    'selling-a-home'   => 'bc-blog-strip-section--selling',
    'buying-a-home'    => 'bc-blog-strip-section--buying',
    'homeowner-guides' => 'bc-blog-strip-section--homeowner',
    'local-insights'   => 'bc-blog-strip-section--local',
];
$strip_subcats = [
    'selling-a-home'   => ['Preparing Your Home' => 'preparing-your-home', 'Pricing Your Home' => 'pricing-your-home', 'Flat Fee MLS' => 'flat-fee-mls', 'FSBO Contracts' => 'fsbo-contracts', 'Selling Process' => 'selling-process', 'Handling Negotiations' => 'handling-negotiations', 'Finances of Selling' => 'finances-of-selling'],
    'buying-a-home'    => ['Buying Process' => 'buying-process', 'Finding a Home' => 'finding-a-home', 'Inspecting a Home' => 'inspecting-a-home', 'Making an Offer' => 'making-an-offer', 'Mortgage Basics' => 'mortgage-basics', 'Moving Tips' => 'moving-tips', 'Preparing to Buy' => 'preparing-to-buy', 'Where to Live' => 'where-to-live'],
    'homeowner-guides' => ['Home Improvements' => 'home-improvements', 'Landscaping' => 'landscaping', 'Lifestyle & Design' => 'lifestyle-design', 'Refinancing' => 'refinancing', 'Renting a Home' => 'renting-a-home'],
    'local-insights'   => ['Florida' => 'florida', 'Georgia' => 'georgia', 'Texas' => 'texas', 'North Carolina' => 'north-carolina', 'South Carolina' => 'south-carolina', 'Ohio' => 'ohio'],
];
foreach ($strip_categories as $strip_label => $strip_slug) :
    $strip_term = get_term_by('slug', $strip_slug, 'category');
    if (!$strip_term) continue;
    $strip_query = new WP_Query([
        'tax_query'      => [['taxonomy' => 'category', 'field' => 'term_id', 'terms' => $strip_term->term_id]],
        'posts_per_page' => 3,
        'post_status'    => 'publish',
    ]);
    if (!$strip_query->have_posts()) { wp_reset_postdata(); continue; }
?>
<section class="bc-blog-strip-section <?php echo esc_attr($strip_modifiers[$strip_slug] ?? ''); ?>">
    <div class="bc-container">
        <div class="bc-blog-strip-header">
            <h2 class="bc-blog-strip-title"><?php echo esc_html($strip_label); ?></h2>
            <a href="<?php echo esc_url(get_category_link($strip_term->term_id)); ?>" class="bc-blog-strip-see-all">See all &rarr;</a>
        </div>
        <?php if (!empty($strip_subcats[$strip_slug])) : ?>
        <div class="bc-blog-strip-subcats">
            <?php foreach ($strip_subcats[$strip_slug] as $sub_label => $sub_slug) :
                $sub = bc_cat($sub_slug);
                $url = $sub['id'] ? $sub['url'] : '#';
            ?>
            <a href="<?php echo esc_url($url); ?>" class="bc-topic-sub"><?php echo esc_html($sub_label); ?></a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="bc-blog-strip-grid">
            <?php while ($strip_query->have_posts()) : $strip_query->the_post(); ?>
            <?php echo beycome_blog_card(get_the_ID(), 'beycome-blog-card', false); ?>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </div>
</section>
<?php endforeach; ?>

<!-- By Location -->
<section class="bc-blog-location-section">
    <div class="bc-container">
        <div class="bc-blog-section-label">BY LOCATION</div>
        <div class="bc-blog-location-tags">
            <?php
            $location_tags = ['Florida', 'Georgia', 'Texas', 'California', 'Illinois', 'North Carolina', 'Ohio', 'Michigan', 'Minnesota', 'Tennessee', 'Virginia', 'Colorado', 'Arizona', 'Nevada', 'Washington', 'New York', 'Pennsylvania', 'Maryland'];
            foreach ($location_tags as $loc) :
                $tag_obj = get_term_by('name', $loc, 'post_tag');
                if ($tag_obj) :
            ?>
            <a href="<?php echo esc_url(get_tag_link($tag_obj->term_id)); ?>" class="bc-location-tag"><?php echo esc_html($loc); ?></a>
            <?php else : ?>
            <span class="bc-location-tag bc-location-tag--inactive"><?php echo esc_html($loc); ?></span>
            <?php endif; endforeach; ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>
